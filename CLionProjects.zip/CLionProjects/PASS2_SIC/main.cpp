#include <bits/stdc++.h>
#include "/home/njaber/CLionProjects/SIC_UTILS/util.h"
using namespace std;
void fill(map<string,string> &OPTAB){
    ifstream optable;
    optable.open("/home/njaber/CLionProjects/OPTAB.txt");
    string line;
    while(optable>>line){
        OPTAB[line] = "1";
    }
    optable.close();
}
bool isValue(string operand){
    int i =0;
    bool value = true;
    while(i<operand.length()){

    }
}
int main() {
    freopen("/home/njaber/CLionProjects/SIC_UTILS/intermediate_file.txt","r",stdin);
    freopen("/home/njaber/CLionProjects/SIC_UTILS/output_program.txt","w",stdout);
    ofstream objprog;
    objprog.open("/home/njaber/CLionProjects/SIC_UTILS/object_program.txt");

    ifstream len;
    len.open("/home/njaber/CLionProjects/SIC_UTILS/length.txt");


    map<string, string> SYMTAB;
    map<string, string> OPTAB;
    string line;
    getline(cin,line);
    string *parsedLine = split(line);
    string opcode = parsedLine[1];
    string length;
    len>>length;
    string error_flag;
    objprog<<"H"<<parsedLine[0]<<parsedLine[2]<<length<<endl;
    if(opcode=="START"){
        cout<<line<<endl;
        getline(cin,line);
    }
    fill(SYMTAB,"SYMTAB");
    fill(OPTAB,"OPTAB");
    while(opcode!="END"){
        string obj_code;
        string *curline = split(line);
        string label = curline[0];
        string operand = curline[2];
        string currentTextRecord = "T";
        if(label!="."){
            string address;
            bool found = OPTAB.find(opcode)!=OPTAB.end();
            if(found){
                if(operand!=" ") {
                    found = SYMTAB.find(operand) != SYMTAB.end();
                    if (found) {
                        address = SYMTAB[operand];
                    } else {
                        address = "0";
                        error_flag = "undefined_symbol";
                    }
                }
                else
                    address = "0";
                obj_code = OPTAB[opcode]+address;

            }else if(opcode == "BYTE"){
                char type = operand[0];
                if (type == 'C') {
                    string valInHex;
                    int z = 2;
                    int counter = 0;
                    while (operand[z] != '\'') {
                        int ASCII = operand[z];
                        string hex = decToHex(ASCII);
                        valInHex += hex;
                        z++;
                    }
                    obj_code = valInHex;
                }
            }else if(opcode == "WORD"){

            }
        }
    }
}