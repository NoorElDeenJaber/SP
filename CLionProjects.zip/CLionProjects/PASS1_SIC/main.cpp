#include <bits/stdc++.h>
#include "/home/njaber/CLionProjects/SIC_UTILS/util.h"

using namespace std;
void inc_LOCCTR(string &LOCCTR,int amount){
    int LOCCTR_dec = hexToDec(LOCCTR);
    LOCCTR_dec += amount;
    LOCCTR = decToHex(LOCCTR_dec);
}
int main() {
    freopen("program.txt", "r", stdin);
    ofstream inter;
    inter.open("/home/njaber/CLionProjects/SIC_UTILS/intermediate_file.txt");

    ofstream len;
    len.open("/home/njaber/CLionProjects/SIC_UTILS/length.txt");

    ofstream symt;
    symt.open("/home/njaber/CLionProjects/SIC_UTILS/SYMTAB.txt");

    map<string, string> SYMTAB;
    map<string, string> OPTAB;
    fill(OPTAB,"OPTAB");
    string line;
    string startingAddress = "1000";
    getline(cin, line);
    string *firstLine = split(line);
    string opcode = firstLine[1];
    string LOCCTR;
    if (opcode == "START") {
        startingAddress =firstLine[2];
        LOCCTR = startingAddress;
    }
    inter<<line<<" "<<LOCCTR<<endl;
    string error_flag;
    while (opcode != "END") {

        getline(cin, line);

        string *curline = split(line);
        string label = curline[0];
        if(label!=".")
            inter <<line<<" "<<LOCCTR<<endl;
        else{
            inter<<line<<endl;
        }
        opcode = curline[1];
        if (label != ".") {
            if (label != " ") {
                if (SYMTAB.find(label) != SYMTAB.end()) {
                    error_flag = "duplicate";
                } else {
                    SYMTAB[label] = LOCCTR;
                    symt<<label<<" "<<LOCCTR<<endl;
                }
            }
            bool found = OPTAB.find(opcode) != OPTAB.end();
            if (found) {
                inc_LOCCTR(LOCCTR,3);
            } else if (opcode == "WORD") {
                inc_LOCCTR(LOCCTR,3);
            } else if (opcode == "RESW") {
                int operand = atoi(curline[2].c_str());
                inc_LOCCTR(LOCCTR,3*operand);
            } else if (opcode == "RESB") {
                int operand = atoi(curline[2].c_str());
                inc_LOCCTR(LOCCTR,operand);
            } else if (opcode == "BYTE") {
                string operand = curline[2];
                char type = operand[0];
                if (type == 'C'||type == 'X') {
                    int z = 2;
                    int counter = 0;
                    while (operand[z++] != '\''&&++counter);
                    inc_LOCCTR(LOCCTR,counter/2);
                }
            } else
                error_flag = "invalid_opcode";
            }
        }
        string length = decToHex(hexToDec(LOCCTR)-hexToDec(startingAddress));
        len<<length<<endl;
        inter.close();
        symt.close();
    }