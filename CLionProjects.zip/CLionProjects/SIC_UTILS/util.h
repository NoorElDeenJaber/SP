//
// Created by njaber on 12/24/17.
//

#ifndef UTIL_H
#define UTIL_H
#include<bits/stdc++.h>
using namespace std;

string* split(string line){
    string *data = new string[10];
    string temp = "";
    int index = 0;
    char prev = line[0];
    if(line[0]==' ')
        data[index++] = " ";
    temp = line[0];
    for(int i=1;i<line.length();++i){
        if(line[i]==' '){
            if(prev!=' ')
                data[index++] = temp;

            temp = "";
        }else{
            temp+=line[i];
        }
        prev = line[i];
    }

    data[index++] = temp;
    return data;
}

string decToHex(int dec){
    string hex;
    while(dec!=0){
        if(dec%16<10){
            hex += dec%16+'0';
        }else{
            hex += dec % 16 - 10 + 'A';
        }
        dec /= 16;
    }
    reverse(hex.begin(),hex.end());
    return hex;
}
int hexToDec(string hex){
    int answer =0;
    int toAdd = 0;
    for(int i= static_cast<int>(hex.length() - 1),j=0; i >= 0; --i,++j){
        toAdd = hex[i]-'0';
        if(hex[i]>='A'&&hex[i]<='F')
            toAdd = 10+hex[i]-'A';
        answer+=toAdd*pow(16,j);
    }
    return answer;
}


void fill(map<string,string> &table,string name){
    ifstream tab;
    tab.open("/home/njaber/CLionProjects/SIC_UTILS/"+name+".txt");
    string line;
    while(tab>>line){
        string *data = split(line);
        table[data[0]] = data[1];
    }
    tab.close();
}

#endif //UTIL_H
